import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class tinyGIS extends JPanel implements MouseListener, ActionListener {

	private ArrayList<POI> poi = new ArrayList<POI>();
	private BufferedImage campus;
	private int buff = 5;
	private JButton labelButton = new JButton("Turn labels on");
	private boolean labelflag = false;
	
	public tinyGIS() { 
		super(true);
		setPreferredSize(new Dimension(699, 446));
		this.addMouseListener(this);
		add(labelButton);
		this.labelButton.addActionListener(this);
	}
	
	public BufferedImage getCampus() {
		return campus;
	}

	public void setCampus(BufferedImage campus) {
		this.campus = campus;
	}
	
	// View 
	
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);    // Paints all other stuff, e.g., background.
		
		g.drawImage(campus, 0, 0, this);
		
		for (int i = 0; i < poi.size(); i++) {
				g.setColor(Color.red);
				poi.get(i).fillOval(g);
			
			if(labelflag) {
				g.setColor(Color.black);
				g.setFont(new Font("default", Font.BOLD, 14));
				poi.get(i).drawName(g);
			}
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) { }

	@Override
	public void mousePressed(MouseEvent e) { }

	@Override
	public void mouseReleased(MouseEvent e) {
		Point tmp = new Point(e.getX(), e.getY());
		POI tmpPOI = new POI(tmp, buff, "Unnamed", false);
		String name = JOptionPane.showInputDialog("Enter POI name: ");
		tmpPOI.setName(name);
		poi.add(tmpPOI);
		
		repaint();
	}

	@Override
	public void mouseEntered(MouseEvent e) {}

	@Override
	public void mouseExited(MouseEvent e) {}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == labelButton) {
			labelflag = !labelflag;
		}
		
		if(labelflag) { 
			labelButton.setText("Turn labels off"); 
		} else { 
			labelButton.setText("Turn labels on");
		}
		
		repaint();
		
	}
}

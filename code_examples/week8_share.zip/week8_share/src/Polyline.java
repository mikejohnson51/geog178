
import java.awt.Graphics;
import java.util.ArrayList;

public class Polyline implements Geometry {
	
	// Member Variables
	private ArrayList <Point> points;
	
	//Constructors
	public Polyline() { setPoints(new ArrayList<Point>()); }
	public Polyline(ArrayList<Point> points) { this.setPoints(points); }
		
	// Getters & setters
	public ArrayList<Point> getPoints(){ return points; }
	public void             setPoints(ArrayList <Point> points) { this.points = points; }
	
	
	// Delegates
	public int size() { return points.size(); }
	public Point remove(int index) { return points.remove(index); }
	public boolean contains(Point p) { return points.contains(p); }
	public Point get(int index) { return points.get(index); }
	public boolean add(Point e) { return points.add(e); }
	public void clear() { points.clear(); }
	public void set(int index, Point p) { points.set(index, p); }
	
	
	@Override
	public String toString() { return "Polyline [points=" + points + "]"; }
	
	// Inteface contracts

	public double getLength() {
		
		double distance = 0;
		
		for (int i = 0; i < (this.size() - 1); i++) {
			distance += this.get(i).distance(this.get(i+1));
		}
		
		return distance;
	}
	
	
	public int getDiminsion() { return 2; }

	public String getType() { return getClass().toString(); }

	public bbox getEnvelope() {
		double xmin = Double.MAX_VALUE, ymin = Double.MAX_VALUE;
		double xmax = Double.MIN_VALUE, ymax = Double.MIN_VALUE;
		
		for (int i = 0; i < this.size(); i++) {
			xmax = Math.max(this.get(i).getX(), xmax);
			xmin = Math.min(this.get(i).getX(), xmin);
			ymax = Math.max(this.get(i).getY(), ymax);
			ymin = Math.min(this.get(i).getY(), ymin);
		}
		
		return(new bbox(new Point(xmin, ymin), new Point(xmax, ymax)));	
	}

	public boolean isEmpty() { return this.size() == 0; }

	public boolean equals(Geometry g) {
		if(this.getClass() != g.getClass())
		    return false;
		if(this.size() != g.getPoints().size())
			return false;
		if(this.getLength() != g.getLength())
			return false;
		
		return true;
	}

	public double getArea() { return 0; }

	public boolean touches(Geometry g) {
		
		for (int i = 0; i < this.size(); i++) { 
			if(g.getPoints().contains(this.getPoints().get(i))) { 
				return true; } 
			}
		return false;
	}
	
	public int numPoints() { return this.size(); }
	
	
	// Draw Methods
	public void drawLine(Graphics g) {
		
		for (int i = 0; i < this.size()-1; i++) {
			g.drawLine( (int)(this.get(i)).getX(), 
						(int)(this.get(i)).getY(), 
						(int)(this.get(i+1)).getX(), 
						(int)(this.get(i+1)).getY());
			}
	}
	
	public void drawPoints(Graphics g) {
		
		for (int i = 0; i < this.size(); i++) {
			// Convert to PointBuffer with 3 pixel radius
			pointBuffer pb = new pointBuffer(this.get(i), 3);
			pb.fillOval(g);
		}
	}
	 
	
	
}


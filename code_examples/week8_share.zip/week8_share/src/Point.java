import java.util.ArrayList;

public class Point implements Geometry {
	
	//Member variables
	private double x, y;
	// Constructors 
	public Point(double x, double y) { this.x = x; this.y = y; }
	public Point() { 
		this.x = Double.NaN;
		this.y = Double.NaN;
	}
	
	//Getters & Setters
	public double getX()         { return x; }
	public void   setX(double x) { this.x = x; }

	public double getY()         { return y; }
	public void   setY(double y) { this.y = y; }

	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Point other = (Point) obj;
		if (Double.doubleToLongBits(x) != Double.doubleToLongBits(other.x))
			return false;
		if (Double.doubleToLongBits(y) != Double.doubleToLongBits(other.y))
			return false;
		return true;
	}

	public String toString() { return "Point [x=" + x + ", y=" + y + "]"; }
	
	// Methods
	public double distance(Point p) {
		return Math.sqrt(Math.pow(this.x-p.getX(), 2) + Math.pow(this.y-p.getY(), 2));
	}
		
	
	public String  getType() { return getClass().toString(); }
 
	public bbox    getEnvelope() { return new bbox(this, this); }

	public boolean isEmpty() { return Double.isNaN(x) || Double.isNaN(y); }

	@Override
	public boolean touches(Geometry g) {
		int touches = 0;
		for (int i = 0; i < g.getPoints().size(); i++) {
			if(this.getPoints().contains(g.getPoints().get(i))) {
				touches++;
			}
		}
		return touches >0;
	}

	public double getArea() { return 0; }

	public double getLength() { return 0; }

	public ArrayList<Point> getPoints() {
		ArrayList<Point> pts = new ArrayList<Point>();
		pts.add(this);
	    return pts;
	}
	
	public int numPoints() { return 1; }
	@Override
	public int getDiminsion() {
		return 0;
	}


}


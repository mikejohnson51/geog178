import java.awt.Graphics;

public class pointBuffer implements Buffer{

	private Point center;
	private double radius;
	
	public pointBuffer(Point center, double radius) {
		this.center = center;
		this.radius = radius;
	}
	

	public Point  getCenter()              { return center; }
	public void   setCenter(Point center)  { this.center = center; }
	public double getRadius()              { return radius; }
	public void   setRadius(double radius) { this.radius = radius; }
	

	@Override
	public String toString() {
		return "pointBuffer [center=" + center + ", radius=" + radius + "]";
	}


	public boolean isInside(Point p) {
		return this.getCenter().distance(p) < this.getRadius();	
	}
	

	public double getArea() {
		return Math.PI * Math.pow(radius, 2);
	}
	
	public bbox getEnvelope() {
		
		return new bbox (new Point(center.getX() - radius, center.getY() - radius), 
				  		new Point(center.getX() + radius, center.getY() + radius));
	}

	
	
	public void drawOval(Graphics g) {
		
		g.drawOval((int)(center.getX() - radius), 
			(int) (center.getY() -  radius), 
			(int) radius * 2, 
			(int) radius * 2);
	}
	
	public void fillOval(Graphics g) {
		
		g.fillOval((int)(center.getX() - radius), 
				(int) (center.getY() -  radius), 
				(int) radius * 2, 
				(int) radius * 2);
	}
}

public interface Buffer {

	public boolean isInside(Point g);
	public double  getArea();

}

import java.awt.Graphics;

public class bbox implements Buffer {

	//Attributes
	double xmax, xmin, ymax, ymin;

	//Constructors
	public bbox(Point p1, Point p2) {
		this.xmax = Math.max(p1.getX(), p2.getX());
		this.xmin = Math.min(p1.getX(), p2.getX());
		this.ymax = Math.max(p1.getY(), p2.getY());
		this.ymin = Math.min(p1.getY(), p2.getY());
	}
	//Getters & Setters
	public double getXmax()            { return xmax; }
	public void   setXmax(double xmax) { this.xmax = xmax; }
	public double getXmin()            { return xmin; }
	public void   setXmin(double xmin) { this.xmin = xmin; }
	public double getYmax()            { return ymax; }
	public void   setYmax(double ymax) { this.ymax = ymax; }
	public double getYmin()            { return ymin; }
	public void   setYmin(double ymin) { this.ymin = ymin; }

	@Override
	public String toString() {
		return "bbox [xmax=" + xmax + ", xmin=" + xmin + ", ymax=" + ymax + ", ymin=" + ymin + "]";
	}

	// Interface Contracts
	public boolean isInside(Point p) {
		return  p.getX()>=this.xmin && p.getX()<=this.xmax && p.getY()>=this.ymin && p.getY()<=this.ymax;
	}
	
	public double getArea() {
		return this.getHeight() * this.getWidth();		
	}
	

	// Graphic specifications
	public void drawRect(Graphics g) {
		g.drawRect((int)  this.getXmin(), 
					(int) this.getYmin(), 
					(int) this.getWidth()  - 1, 
					(int) this.getHeight() - 1);
	}
	
	public void fillRect(Graphics g) {
		
		g.fillRect((int)  this.getXmin(), 
					(int) this.getYmin(), 
					(int) this.getWidth() - 1, 
					(int) this.getHeight() -1);
	}
	
	// Our methods 
	public bbox modifyEnvelope(bbox bb) {
		return new bbox(new Point(Math.max(this.xmax, bb.getXmax()), Math.max(this.ymax, bb.ymax)),
		new Point(Math.min(this.xmin, bb.getXmin()), Math.min(this.ymin, bb.ymin)));
	}
	
	
	public Point randPoint() {
		return new Point(Math.random() * (this.getXmax() - this.getXmin()) + this.getXmin(),
				         Math.random() * (this.getYmax() - this.getYmin()) + this.getYmin());
		}
	
	public double getWidth()  { return (xmax - xmin); }
	
	public double getHeight() { return (ymax - ymin); }
			

}

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class example1 extends JPanel implements ActionListener{
	
	private JTextField numDots = new JTextField("How Many Dots?");
	private JButton button1 = new JButton("Redraw!");
	private int n = 10;
	int xmax = 500;
	int ymax = 500;
	
	public example1() {
		super(true); 
		setPreferredSize(new Dimension(xmax, ymax));
		// add all J elements
		add(numDots);
		add(button1);
	}

	public void paintComponent(Graphics g) {

        bbox bb = new bbox(new Point(0,0), new Point(xmax,ymax));
        
    	for(int i=0; i<n; i++) {
        	pointBuffer pb = new pointBuffer(bb.randPoint(), 5);
    		g.setColor(Color.blue);
        	pb.fillOval(g);
    	}

	}
	
	
	public static void main(String[] args) throws InterruptedException {
		
		// Here is our frame!
		JFrame frame = new JFrame("All the dots!");
		
		// Here what we will put in the framw
		example1 aPanel = new example1();
		aPanel.button1.addActionListener(aPanel);
		
		// Add, pack, make viable and allow clousure!
		frame.add(aPanel);
		frame.pack();
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}



@Override
public void actionPerformed(ActionEvent e) {
	if(e.getSource() == button1) {
		n  = Integer.decode(numDots.getText());
		repaint();
	}
	
}

	

}


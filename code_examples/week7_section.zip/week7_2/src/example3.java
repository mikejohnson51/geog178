import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class example3 extends JPanel implements ActionListener {
	
	private pointBuffer c = new pointBuffer(new Point(300,300), 50);
	private bbox r = new bbox(new Point(40,40), new Point (180,180));
	private Polyline pl = new Polyline();

	private JButton button1 = new JButton("Draw Bounding Boxs!");
	private boolean drawBBs  = false;
	
	private JButton button2 = new JButton("Draw Bounding Box!");
	private boolean drawBB  = false;


public example3() {
	super(true);
	setPreferredSize(new Dimension (500,500));
	add(button1);
	add(button2);
}

public void paintComponent(Graphics g) {
	
	pl.add(new Point(300, 50));
	pl.add(new Point(400, 75));
	pl.add(new Point(350, 50));
	
	g.setColor(Color.black);
	c.drawOval(g);
	r.draw(g);
	pl.drawLine(g);
	pl.drawPoints(g);
	
 
   if(drawBBs) {
	   g.setColor(Color.green);
	   c.getEnvelope().draw(g);
	   r.draw(g);
	   pl.getEnvelope().draw(g);
   }
   
   if(drawBB) {
	 g.setColor(Color.blue);
     bbox bb = c.getEnvelope().modifyEnvelope(r);
     bb = bb.modifyEnvelope(pl.getEnvelope());
     bb.draw(g);
   }
}
 

public static void main(String[] args) throws InterruptedException{
	
	JFrame frame = new JFrame("Example 3");
	
	
	example3 panel = new example3();
	panel.button1.addActionListener(panel);
	panel.button2.addActionListener(panel);
	
	frame.add(panel);
	frame.pack();
	frame.setVisible(true);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}

@Override
public void actionPerformed(ActionEvent e) {
	if(e.getSource() == button1) {
		drawBBs = true;
		repaint();
	}
	
	if(e.getSource() == button2) {
		drawBB = true;
		repaint();
	}
	
}

}

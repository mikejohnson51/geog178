

import java.util.ArrayList;

public interface Geometry {
	
	public  int getDiminsion();
	
	public  String getType();
	
	boolean touches(Geometry g);
	
	public bbox getEnvelope();
	
	public boolean isEmpty();

	public boolean equals(Object g);
	
	public double getArea();
	
	public double getLength();
	
	public int numPoints();
	
	public ArrayList<Point> getPoints();
	
}






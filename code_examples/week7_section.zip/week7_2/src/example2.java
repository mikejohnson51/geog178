import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class example2 extends JPanel implements ActionListener {
	
	private Polyline pl;
	private JTextField snapText = new JTextField("Enter Snap Distance");
	private JButton snapButton  = new JButton("Snap Distance?");
	double snapBuffer = 10; 
	
	public example2() {
		super(true); 
		pl = new Polyline();
		setPreferredSize(new Dimension(500,500));
		add(snapText);
		add(snapButton);
	}
	
	public void paintComponent(Graphics g) {
		
		if (pl.get(0).distance(pl.get(pl.size()-1)) <= snapBuffer) {
			pl.set(pl.size()-1, pl.get(0));
		}
	
		pl.drawLine(g);
		if(pl.get(0) == pl.get(pl.size()-1)) {
			g.setColor(Color.red);
			pl.drawPoints(g);
		}	else {
			pl.drawPoints(g);
		}
	}

	public static void main(String[] args) {
	
		JFrame frame = new JFrame("Frame");
		
		example2 panel = new example2();

		panel.pl.add(new Point(150,150));
		panel.pl.add(new Point(250,250));
		panel.pl.add(new Point(350,250));
		panel.pl.add(new Point(140,140));
		panel.snapButton.addActionListener(panel);
		
		frame.add(panel);
		frame.pack();
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == snapButton) {
			snapBuffer = Integer.decode(snapText.getText());
			repaint();
		}	
	}
}

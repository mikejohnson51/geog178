import javax.swing.JFrame;

public class run {

	public static void main(String[] args) {
	
		COVID19_int panel = new COVID19_int(80, 60, .6);

		JFrame frame = new JFrame("COVID-19 Model");
		frame.add(panel);
		frame.pack();
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
	}

}

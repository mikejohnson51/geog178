import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JPanel;

public class COVID19_agent extends JPanel implements ActionListener {
	
	public static final int SUSCEPTIBLE = 1;
	public static final int INFECTIOUS = 2;
	public static int REMOVED = Integer.MAX_VALUE;
	public JButton tickButton = new JButton("Tick");
	
	int[][] field;
	int rows;
	int columns;
	
	double density;
	double infectionRate;
	Random r;
	
	public COVID19_agent(int columns, int rows, double density, double infectionRate){
		super(true);
		this.setBackground(Color.white);	
		//this.setPreferredSize(new Dimension((columns*10)+ 70, (rows*10) + 70));
		this.setPreferredSize(new Dimension(870,870));
	    this.rows = rows;
	    this.columns = columns;
		
		this.r = new Random();
		add(tickButton);
		this.tickButton.addActionListener(this);

		int[][] seed = new int[columns][rows];

		for (int i = 0; i < columns ; i++) {
			for (int j = 0; j < rows; j++) {
				
				if(Math.random()<density){
					seed[i][j] = SUSCEPTIBLE;
				}
				if(Math.random()<infectionRate){
					seed[i][j] = INFECTIOUS;
				}
			}
		}
		
		this.setField(seed);
		
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		for (int i = 0; i < columns; i++) {
			for (int j = 0; j < rows; j++) {
				if(field[i][j] == SUSCEPTIBLE) {
					g.setColor(Color.green);
					g.fillRect(30+(10*i), 30+(10*j), 10, 10);
					g.setColor(Color.black);
				} 
				
				if( field[i][j] >= INFECTIOUS && field[i][j] <= REMOVED) {
					g.setColor(Color.red);
					g.fillRect(30+(10*i), 30+(10*j), 10, 10);
					g.setColor(Color.black);
				} 
				
				if( field[i][j] > REMOVED) {
					g.setColor(Color.gray);
					g.fillRect(30+(10*i), 30+(10*j), 10, 10);
					g.setColor(Color.black);
				} 
				
				
				g.drawRect(30+(10*i), 30+(10*j), 10, 10);
			}
		}
		
	}

	public int[][] getField() {
		return field;
	}

	public void setField(int[][] field) {
		this.field = field;
	}
	
	public int getNeighbors(int x, int y) {
		int count = 0; 
		
	    for(int i=x-1; i<=x+1;i++){
	        if(i<columns && i>=0){
	            for(int j=y-1; j<=y+1;j++){
	                if(j<rows && j>=0){
	                    if (field[i][j]>SUSCEPTIBLE && field[i][j]<=REMOVED) {
	                        count++;
	                    }
	                }
	            }
	        }
	    }
		return count;
		
	}
	
	public void tick() {
		int[][] nextField =  new int[columns][rows];
		
		for (int i = 0; i < columns; i++) {
			for (int j = 0; j < rows; j++) {
				
				if(field[i][j]==SUSCEPTIBLE && getNeighbors(i, j)>0 && r.nextDouble()<.5)
					nextField[i][j]=INFECTIOUS;
				else if (field[i][j]>SUSCEPTIBLE && field[i][j]<=REMOVED)
					nextField[i][j] = field[i][j]+1;
				else
					nextField[i][j]=field[i][j];
			}
		}
		this.setField(nextField);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == tickButton) {
			System.out.println("tick button");
			this.tick();
			repaint();
		}
		
	}
}

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;

public class COVID19_int extends JPanel {
	
	int[][] field;
	int rows;
	double density;
	int columns;
	
	public COVID19_int(int columns, int rows, double density){
		super(true);
		this.setBackground(Color.white);	
		this.rows = rows;
		this.columns = columns;

		int[][] seed = new int[columns][rows];

		for (int i = 0; i < columns ; i++) {
			for (int j = 0; j < rows; j++) {
				double rand = Math.random();
				if(Math.random() < density) { 
					seed[i][j] = 1; 
				}
			}
		}
		
		this.setField(seed);
		this.setPreferredSize(new Dimension((10*columns) + 70, (10*rows) + 70));
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		int w = 20;
		for (int i = 0; i < columns; i++) {
			for (int j = 0; j < rows; j++) {
				if(field[i][j] == 1) {
					g.setColor(Color.green);
					g.fillRect(30+(10*i), 30+(10*j), 10, 10);
					g.setColor(Color.black);
				}
				g.drawRect(30+(10*i), 30+(10*j), 10, 10);
			}
		}
		
	}

	public int[][] getField() {
		return field;
	}

	public void setField(int[][] field) {
		this.field = field;
	}
	
	

}



// Imports
import java.util.ArrayList;


public class Polyline {
	
	//Member Variables
	private ArrayList <Point> points;
	
	//Constructors
	public Polyline() { setPoints(new ArrayList<Point>()); }
	public Polyline(ArrayList<Point> points) { this.setPoints(points); }
		
	// Getters 
	public ArrayList<Point> getPoints(){ return points; }
	public void setPoints(ArrayList <Point> points) { this.points = points; }
	
	
	// Delegates
	public int size() { return points.size(); }
	public Point remove(int index) { return points.remove(index); }
	public boolean contains(Point p) { return points.contains(p); }
	public Point get(int index) { return points.get(index); }
	public boolean add(Point e) { return points.add(e); }
	public void clear() { points.clear(); }
	
	
	@Override
	public String toString() { return "Polyline [points=" + points + "]"; }
	
	//Methods

	public double getLength() {
		
		double distance = 0;
		
		for (int i = 0; i < (this.size() - 1); i++) {
			distance += this.get(i).distance(this.get(i+1));
		}
		
		return distance;
	}
	
	public boolean touches(Polyline pl){
		
		int touch = 0;
		
		for (int i = 0; i < this.size(); i++) { if(pl.contains(this.get(i))) { touch++; } }
		
		return touch > 0;
	}
}




import java.util.ArrayList;

public class bbox {

	//Attributes
	double xmax, xmin, ymax, ymin;

	//Constructors
	public bbox(Point p1, Point p2) {
		this.xmax = Math.max(p1.getX(), p2.getX());
		this.xmin = Math.min(p1.getX(), p2.getX());
		this.ymax = Math.max(p1.getY(), p2.getY());
		this.ymin = Math.min(p1.getY(), p2.getY());
	}
	
	public double getXmax() { return xmax; }
	public void   setXmax(double xmax) { this.xmax = xmax; }

	public double getXmin() { return xmin; }
	public void   setXmin(double xmin) { this.xmin = xmin; }

	public double getYmax() { return ymax; }
	public void   setYmax(double ymax) { this.ymax = ymax; }

	public double getYmin() { return ymin; }
	public void   setYmin(double ymin) { this.ymin = ymin; }

	@Override
	public String toString() {
		return "bbox [xmax=" + xmax + ", xmin=" + xmin + ", ymax=" + ymax + ", ymin=" + ymin + "]";
	}

	public boolean isInside(Point p) {
		return  p.getX()>=this.xmin && p.getX()<=this.xmax && p.getY()>=this.ymin && p.getY()<=this.ymax;
	}
	
	public Point randPoint() {
		  double x = Math.random() * (this.getXmax() - this.getXmin()) + this.getXmin();
		  double y = Math.random() * (this.getYmax() - this.getYmin()) + this.getYmin();
		  return new Point(x,y);
		}
			
	public Polygon toPolygon() {
	 
	ArrayList<Point> pts = new ArrayList<Point>();
	 // Remeber outer-rings are listed counter-clockwise
	 pts.add(new Point(this.xmin, this.ymin));
	 pts.add(new Point(this.xmax, this.ymin));
	 pts.add(new Point(this.xmax, this.ymax));
	 pts.add(new Point(this.xmin, this.ymax));
	 pts.add(new Point(this.xmin, this.ymin));
	 
	 return new Polygon(pts);
	}	
}



import java.util.ArrayList;

public class Polygon extends Polyline {
	
	public Polygon() { setPoints(new ArrayList<Point>()); }
		
	public Polygon(ArrayList<Point> points) {super(points); }

	@Override
	public String toString() { return "Polygon " + getPoints(); }	

	
	public bbox getBB() {
		double xmin = Double.MAX_VALUE, ymin = Double.MAX_VALUE;
		double xmax = Double.MIN_VALUE, ymax = Double.MIN_VALUE;
		
		for (int i = 0; i < this.size(); i++) {
			xmax = Math.max(this.get(i).getX(), xmax);
			xmin = Math.min(this.get(i).getX(), xmin);
			ymax = Math.max(this.get(i).getY(), ymax);
			ymin = Math.min(this.get(i).getY(), ymin);
		}
		
		return(new bbox(new Point(xmin, ymin), new Point(xmax, ymax)));	
	}
}



public class Person {
	
	//attribute
		private Point location;
		private int   state; // 1=s, 2=i, 3=r.

		public Person(Point location, int state) {
			super();
			this.location = location;
			this.state = state;

		}

		public Point getLocation() { return location; }
		public void setLocation(Point location) { this.location = location; }
		public int getState() { return state; }
		public void setState(int state) { this.state = state; }

		@Override
		public String toString() {
			return "Person [location=" + location + ", state=" + state + "]";
		}

}

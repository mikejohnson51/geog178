
public class Example1 {

	public static void main(String[] args) {
		
		
//		Part 1: What's in a point?
		
		//The latitude of location 1 is given as a double variable
		double lat = 34.4139;
		
		//The longitude of location 1 is given as a double variable
		double lng = -119.8489;
		
		//Location of interest given as a string variable
		String name = "UCSB";
		
		// A print statement is used to combine our three variables
		
		System.out.println(name + " is located at " + 
						   lat + " degress latitude and " + 
						   lng + " degrees longitude.");

	}
	

}

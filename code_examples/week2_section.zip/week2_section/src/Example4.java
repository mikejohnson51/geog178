
public class Example4 {
	
	public static void main(String[] args) {

		
		Here's some text!  Lets comment it with  CMD + SHIFT + C
		 
//		We can un-comment to using the same keys. Uncomment and the delete!
			
	  Sometimes we want to provide long comments sometimes these might be answers
	  to HW questions ;) sometimes there are used to describe the purpose of a
	  class or program either way they can be lonnnnnnnggggggg... Lets comment
	  these type of functions with CTL + CMD + /  ... Go ahead and comment me out!
	  
	
	 /*Unfortunately, the keyboard shortcut for un-commenting
		 a long block comment is
		 CTL + CMD + \  .... un-comment me and delete */

		
		for(int i=0; i <10; i++) {
			System.out.println("for: " + i);
		}
		
		
		int count = 0;
		
		while(count < 10) {
			System.out.println("while: " + count);
			count++;
		}
		
		

	}

}

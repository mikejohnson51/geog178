
//Things to look at:
//  1. Variable typing
//	2. Using a external package (Math)
//	3. Commonalities between same-type objects
//	4. Commonalities between same-type operations (methods)


public class Example2 {

		public static void main(String[] args) {
		// Define Points
			
			//POINT 1
			String name1 = "UCSB";
			double lat1 = 34.4139;
			double lng1 = -119.8489;
			
			//POINT 2
			String name2 = "Cheyenne Mountain";
			double lat2 = 38.8031;
			double lng2 = -104.8572;
			
			
		// The latitudes, given as a double variables, are converted to radians 
		// This is done using the 'toRadians' tool in the 'Math' package

			lat1 = Math.toRadians(lat1);
			lat2 = Math.toRadians(lat2); // Enter your data!
			
		// The longitudes given as a double variable in radians
			lng1 = Math.toRadians(lng1); 
			lng2 = Math.toRadians(lng2);
			
			
		// Determine change in lat and long between locations:
			double d_lat = Math.abs(lat2 - lat1);
			double d_lon = Math.abs(lng2 - lng1);
			
			/* Apply the Haversine Formula 
				The Math package is used again for sin, cos, arctan2, and square root operators
				The 'Math.pow(variable, 2) is a method for squaring a number */
			
			double a = Math.pow(Math.sin(d_lat/2),2) + (Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(d_lon/2),2));
			double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
			
			// To get the distance in miles we multiply by the radius of the earth - 3,961 miles
			double d = 3961 * c;
			
			//A print statement is used to provide our answer
			System.out.println(name2 + " is " + Math.round(d) + " miles from " + name1); 

		}
	}


